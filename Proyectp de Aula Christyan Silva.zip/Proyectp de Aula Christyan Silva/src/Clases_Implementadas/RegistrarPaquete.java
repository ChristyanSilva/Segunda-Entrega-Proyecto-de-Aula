package Clases_Implementadas;

public class RegistrarPaquete {
    private int nopaquete ;
    private int fechaingreso ;
    private String nombrecompleto ;
    private String dirdestino;
    private int viviendadestino ;
    private int codepostalpaquete ;
    private String diremitente ;
    private int viviendaremitente ;
    private String pais ;
    private String ciudad ;
    private int telefonoremitente ;
    private String tipopaquete ;
    private String descripcionpaquete ;
    private double largopaquete ;
    private double anchopaquete ;
    private double altopaquete ;
    private double pesopaquete ;
    private double valorpaquete ;
    private String estadopaquete ;
    private String fechalimite ;
    private String observacion ;

    public int getNopaquete() {
        return nopaquete;
    }

    public void setNopaquete(int nopaquete) {
        this.nopaquete = nopaquete;
    }

    public int getFechaingreso() {
        return fechaingreso;
    }

    public void setFechaingreso(int fechaingreso) {
        this.fechaingreso = fechaingreso;
    }

    public String getNombrecompleto() {
        return nombrecompleto;
    }

    public void setNombrecompleto(String nombrecompleto) {
        this.nombrecompleto = nombrecompleto;
    }

    public String getDirdestino() {
        return dirdestino;
    }

    public void setDirdestino(String dirdestino) {
        this.dirdestino = dirdestino;
    }

    public int getViviendadestino() {
        return viviendadestino;
    }

    public void setViviendadestino(int viviendadestino) {
        this.viviendadestino = viviendadestino;
    }

    public int getCodepostalpaquete() {
        return codepostalpaquete;
    }

    public void setCodepostalpaquete(int codepostalpaquete) {
        this.codepostalpaquete = codepostalpaquete;
    }

    public String getDiremitente() {
        return diremitente;
    }

    public void setDiremitente(String diremitente) {
        this.diremitente = diremitente;
    }

    public int getViviendaremitente() {
        return viviendaremitente;
    }

    public void setViviendaremitente(int viviendaremitente) {
        this.viviendaremitente = viviendaremitente;
    }

    public String getPais() {
        return pais;
    }

    public void setPais(String pais) {
        this.pais = pais;
    }

    public String getCiudad() {
        return ciudad;
    }

    public void setCiudad(String ciudad) {
        this.ciudad = ciudad;
    }

    public int getTelefonoremitente() {
        return telefonoremitente;
    }

    public void setTelefonoremitente(int telefonoremitente) {
        this.telefonoremitente = telefonoremitente;
    }

    public String getTipopaquete() {
        return tipopaquete;
    }

    public void setTipopaquete(String tipopaquete) {
        this.tipopaquete = tipopaquete;
    }

    public String getDescripcionpaquete() {
        return descripcionpaquete;
    }

    public void setDescripcionpaquete(String descripcionpaquete) {
        this.descripcionpaquete = descripcionpaquete;
    }

    public double getLargopaquete() {
        return largopaquete;
    }

    public void setLargopaquete(double largopaquete) {
        this.largopaquete = largopaquete;
    }

    public double getAnchopaquete() {
        return anchopaquete;
    }

    public void setAnchopaquete(double anchopaquete) {
        this.anchopaquete = anchopaquete;
    }

    public double getAltopaquete() {
        return altopaquete;
    }

    public void setAltopaquete(double altopaquete) {
        this.altopaquete = altopaquete;
    }

    public double getPesopaquete() {
        return pesopaquete;
    }

    public void setPesopaquete(double pesopaquete) {
        this.pesopaquete = pesopaquete;
    }

    public double getValorpaquete() {
        return valorpaquete;
    }

    public void setValorpaquete(double valorpaquete) {
        this.valorpaquete = valorpaquete;
    }

    public String getEstadopaquete() {
        return estadopaquete;
    }

    public void setEstadopaquete(String estadopaquete) {
        this.estadopaquete = estadopaquete;
    }

    public String getFechalimite() {
        return fechalimite;
    }

    public void setFechalimite(String fechalimite) {
        this.fechalimite = fechalimite;
    }

    public String getObservacion() {
        return observacion;
    }

    public void setObservacion(String observacion) {
        this.observacion = observacion;
    }
    
    public RegistrarPaquete(){
        
    }

    public void DatosDestinatario(){
        
    }
    public void DatosRemitente(){
        
    }
    public void DatosPaquete(){
        
    }
    public void Observaciones(){
        
    }
    public void ValCodePostal(){
        
    }
    
}
