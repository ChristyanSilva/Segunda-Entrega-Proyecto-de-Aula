/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Clases_Implementadas;

/**
 *
 * @author CRISTIAN
 */
public class Repartidor {
    private int docrepartidor ;
    private String nombrepartidor ;
    private int zonasignadas ;
    private char categoriarepartidor ;
    private String usuario ;
    private String contraseña ;

    public int getDocrepartidor() {
        return docrepartidor;
    }

    public void setDocrepartidor(int docrepartidor) {
        this.docrepartidor = docrepartidor;
    }

    public String getNombrepartidor() {
        return nombrepartidor;
    }

    public void setNombrepartidor(String nombrepartidor) {
        this.nombrepartidor = nombrepartidor;
    }

    public int getZonasignadas() {
        return zonasignadas;
    }

    public void setZonasignadas(int zonasignadas) {
        this.zonasignadas = zonasignadas;
    }

    public char getCategoriarepartidor() {
        return categoriarepartidor;
    }

    public void setCategoriarepartidor(char categoriarepartidor) {
        this.categoriarepartidor = categoriarepartidor;
    }

    public String getUsuario() {
        return usuario;
    }

    public void setUsuario(String usuario) {
        this.usuario = usuario;
    }

    public String getContraseña() {
        return contraseña;
    }

    public void setContraseña(String contraseña) {
        this.contraseña = contraseña;
    }
    
    
    public void RegistroRepartidor(){
        
    }
    public void ValidacionRepartidor(){
        
    }
    public void Asignacionpaquetes(){
        
    }
    public void Listadepaquetes(){
        
    }
    public void DescripcionRepartidor(){
        
    }
    
        
}
