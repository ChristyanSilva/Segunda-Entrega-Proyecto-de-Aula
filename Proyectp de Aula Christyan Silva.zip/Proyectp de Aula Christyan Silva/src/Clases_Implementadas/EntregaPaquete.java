/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Clases_Implementadas;

/**
 *
 * @author CRISTIAN
 */
public class EntregaPaquete {
    private String fechavisita ;
    private String horavisita ;
    private String estadoentrega ;
    private String observacuionentrega  ;
    private int visitasrepartidor  ;

    public String getFechavisita() {
        return fechavisita;
    }

    public void setFechavisita(String fechavisita) {
        this.fechavisita = fechavisita;
    }

    public String getHoravisita() {
        return horavisita;
    }

    public void setHoravisita(String horavisita) {
        this.horavisita = horavisita;
    }

    public String getEstadoentrega() {
        return estadoentrega;
    }

    public void setEstadoentrega(String estadoentrega) {
        this.estadoentrega = estadoentrega;
    }

    public String getObservacuionentrega() {
        return observacuionentrega;
    }

    public void setObservacuionentrega(String observacuionentrega) {
        this.observacuionentrega = observacuionentrega;
    }

    public int getVisitasrepartidor() {
        return visitasrepartidor;
    }

    public void setVisitasrepartidor(int visitasrepartidor) {
        this.visitasrepartidor = visitasrepartidor;
    }
    
    public void DatosdelPaquete(){
        
    }
    
}
